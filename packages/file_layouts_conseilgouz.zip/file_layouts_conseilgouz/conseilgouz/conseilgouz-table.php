<?php
/**
 * @copyright   Copyright (C) ConseilGouz. All rights reserved.
   @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

extract($displayData);


// Build heading
$table_head = '';

if (!empty($groupByFieldset))
{

	$sublayout = 'section-byfieldsets';
}
else
{
	$sublayout = 'section';
	// Label will not be shown for sections layout, so reset the margin left
	JFactory::getDocument()->addStyleDeclaration(
		'.subform-table-sublayout-section .controls { margin-left: 0px }
		'
	);
}
JFactory::getDocument()->addStyleDeclaration(
	'.subform-conseilgouz-wrapper.subform-table-layout.controls { margin-bottom: 18px; }
     .subform-conseilgouz-wrapper.subform-table-layout.control-group, .subform-table-layout.control-group:last-of-type {
			margin-bottom: -1em;} 	
	@media (max-width: 1024px) {
		.subform-table-layout td {
		border: none;
		position: relative;
		padding-left: 0;
		}
	}
	.decalgouz {margin-left: -160px; width:inherit}
	@media (max-width: 767px) {
		.decalgouz {margin-left: 0}
	}
	'
);

?>

<div class="row-fluid decalgouz" >
	<div class="subform-conseilgouz-wrapper subform-table-layout subform-table-sublayout-<?php echo $sublayout; ?>" >
		<table class="adminlist table table-striped table-bordered">
			<tbody>
			<?php
			foreach ($forms as $k => $form) :
				echo $this->sublayout($sublayout, array('form' => $form, 'basegroup' => $fieldname, 'group' => $fieldname . $k, 'buttons' => $buttons));
			endforeach;
			?>
			</tbody>
		</table>
	</div>
</div>
