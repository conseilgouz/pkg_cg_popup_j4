# mod_cg_popup_j4
 CG Popup for Joomla 4.x
