# mod_cg_popup_j4
 CG Popup for Joomla 4.x

Voir https://www.conseilgouz.com/simple-popup
